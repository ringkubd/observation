<?php

namespace App\observation;

use Illuminate\Database\Eloquent\Model;

class ObservationStag5Cat extends Model {
	protected $table = 'obdervation_stage5_category';
	protected $connection = 'mysql_view';

}