<?php

namespace App\observation;

use Illuminate\Database\Eloquent\Model;

class ObservationStag10Cat extends Model {
	protected $table = 'obdervation_stage10_category';
	protected $connection = 'mysql_view';

}