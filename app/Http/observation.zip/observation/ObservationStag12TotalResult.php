<?php

namespace App\observation;

use Illuminate\Database\Eloquent\Model;

class ObservationStag12TotalResult extends Model {
	protected $table = 'observation_stag_12_total_field_result';
	protected $connection = 'mysql_view';

}