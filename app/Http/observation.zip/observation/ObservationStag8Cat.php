<?php

namespace App\observation;

use Illuminate\Database\Eloquent\Model;

class ObservationStag8Cat extends Model {
	protected $table = 'observation_stag_8_cat';
	protected $connection = 'mysql_view';

}