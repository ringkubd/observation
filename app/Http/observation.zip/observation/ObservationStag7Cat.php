<?php

namespace App\observation;

use Illuminate\Database\Eloquent\Model;

class ObservationStag7Cat extends Model {
	protected $table = 'obdervation_stage7_category';
	protected $connection = 'mysql_view';

}