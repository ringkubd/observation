<?php

namespace App\observation;

use Illuminate\Database\Eloquent\Model;

class SocialFardigheter50 extends Model {
	protected $table = 'social_fardigheter_50';
	protected $connection = 'mysql_view';

}