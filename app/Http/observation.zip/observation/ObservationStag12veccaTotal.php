<?php

namespace App\observation;

use Illuminate\Database\Eloquent\Model;

class ObservationStag12veccaTotal extends Model {
	protected $table = 'observation_12_vecca_total';
	protected $connection = 'mysql_view';

}