<?php

namespace App\operant;

use Illuminate\Database\Eloquent\Model;

class VeccaWiseBaselineData extends Model {
	protected $connection = 'mysql_view';
	protected $table = 'vecca_wise_baseline_data';

	

}