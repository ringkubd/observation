<?php

namespace App\operant;

use Illuminate\Database\Eloquent\Model;

class ClientWiseLevelConfigVasRealConfiguration extends Model {
    protected $table = 'client_wise_level_config_vas_real_configuration';
    protected $connection = 'mysql_view';

}
