<?php

namespace App\operant;
use Illuminate\Database\Eloquent\Model;

class GenerateOperantStatus extends Model {
    protected $connection = 'mysql_view';
    
}