<?php

namespace App\operant;

use Illuminate\Database\Eloquent\Model;

class TotalBlockBaseLine extends Model {
	protected $table = 'total_block_base_line';
	protected $connection = 'mysql_view';

}